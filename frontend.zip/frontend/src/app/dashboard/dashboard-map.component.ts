import { Component, OnInit } from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { HttpClient } from '@angular/common/http';
import { CommonModule, NgIf } from '@angular/common';

@Component({
  selector: 'app-dashboard-map',
  imports: [NgIf],
  templateUrl: './dashboard-map.component.html',
  styleUrls: ['./dashboard-map.component.css']
})
export class DashboardMapComponent implements OnInit {
  svgContent: SafeHtml = '';
  tooltipVisible = false;
  tooltipX = 0;
  tooltipY = 0;
  tooltipText = '';

  torcedores: Record<string, number> = {};

  constructor(private sanitizer: DomSanitizer, private http: HttpClient) {}

  ngOnInit(): void {
    this.loadSVG();
    this.fetchData();
  }

  fetchData(): void {
    this.http.get<any[]>('http://localhost:8080/usuario/estados').subscribe(data => {
      this.torcedores = {};
      data.forEach(item => {
        this.torcedores[item.estado.toUpperCase()] = item.quantidade;
      });
      this.updateEventHandlers();
    });
  }

  loadSVG(): void {
    fetch('/assets/br.svg')
      .then(response => response.text())
      .then(svg => {
        this.svgContent = this.sanitizer.bypassSecurityTrustHtml(svg);
        setTimeout(() => this.updateEventHandlers(), 0);
      });
  }

  updateEventHandlers(): void {
    const svgElement = document.querySelector('#svg-container svg');
    if (!svgElement) return;

    svgElement.querySelectorAll<SVGElement>('.state').forEach(stateEl => {
      const stateId = stateEl.id?.toUpperCase();

      stateEl.addEventListener('mousemove', (event: MouseEvent) => {
        const count = this.torcedores[stateId] || 0;
        this.tooltipText = `${stateId}: ${count} torcedores`;
        this.tooltipVisible = true;
        this.tooltipX = event.clientX + 10;
        this.tooltipY = event.clientY + 10;
      });

      stateEl.addEventListener('mouseleave', () => {
        this.tooltipVisible = false;
      });
    });
  }
}
